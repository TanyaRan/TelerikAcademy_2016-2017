/* globals module */

module.exports = {
    port: 3001,
    connectionString: "mongodb://localhost/superheroesDb"
};