# ExpressJS Homework

1. Create a web site (with normal design) using ExpressJS with private and public parts � CRUD operations over a model by your choice 
	* At least 6 pages
	* Use Express
	* Use File upload
	* Use Jade
	* Use Stylus
	* Use Passport module for authentication
	* Use good application architecture
