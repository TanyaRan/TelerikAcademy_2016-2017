class Genre {
    constructor(name, moviesIds) {
        this.name = name;
        this.moviesIds = moviesIds;
    }
}

module.exports = { Genre };
