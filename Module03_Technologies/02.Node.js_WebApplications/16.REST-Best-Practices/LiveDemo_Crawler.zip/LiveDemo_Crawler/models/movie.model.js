class Movie {
    constructor(title, posterUrl) {
        this.title = title;
        this.posterUrl = posterUrl;
    }
}

module.exports = { Movie };
