module.exports = require('./dom-parser');
