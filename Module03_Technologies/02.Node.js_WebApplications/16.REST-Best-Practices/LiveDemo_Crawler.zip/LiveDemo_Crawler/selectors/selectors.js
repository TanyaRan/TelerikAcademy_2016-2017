module.exports = {
    DETAILS: {
        TITLE_SELECTOR: '.title_wrapper h1',
        POSTER_IMG_URL: '.poster a img',
    },
};
