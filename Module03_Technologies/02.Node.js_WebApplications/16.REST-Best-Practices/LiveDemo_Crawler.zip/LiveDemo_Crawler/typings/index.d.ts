/// <reference path="globals/isomorphic-fetch/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
