module.exports = require('./router');
