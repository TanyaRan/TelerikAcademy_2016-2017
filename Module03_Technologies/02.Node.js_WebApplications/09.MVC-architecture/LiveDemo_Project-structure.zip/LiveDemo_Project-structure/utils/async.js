const async = () => {
    return Promise.resolve();
};

module.exports = async;
