const port = 3001;
const connectionString = 'mongodb://localhost/items-db';
const sessionSecret = 'Purple Unicorn';

module.exports = { port, connectionString, sessionSecret };
