(function () {
	setInterval(function () {
		logger.log('log', new Date());
	}, 1000);
}());