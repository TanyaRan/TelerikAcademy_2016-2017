/// <reference path="globals/crypto-js/index.d.ts" />
