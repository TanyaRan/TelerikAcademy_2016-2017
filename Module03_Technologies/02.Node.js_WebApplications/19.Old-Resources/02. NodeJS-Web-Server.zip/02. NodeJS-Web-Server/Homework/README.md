# NodeJS Web Server Homework

1. Create **web site** with NodeJS in which you can **upload files**.
	* You should have the option to upload a file and be given an unique URL for its **download**.
	* Use **GUID for file urls** (e.g. `/file/797ff043-11eb-11e1-80d6-510998755d10.mp3`)
	* You are **not allowed to use ExpressJS**
