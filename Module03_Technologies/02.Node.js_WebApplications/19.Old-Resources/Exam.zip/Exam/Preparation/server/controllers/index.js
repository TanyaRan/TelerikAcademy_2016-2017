var UsersController = require('./UsersController'),
    EventsController = require('./EventsController');

module.exports = {
    users: UsersController,
    events: EventsController
};