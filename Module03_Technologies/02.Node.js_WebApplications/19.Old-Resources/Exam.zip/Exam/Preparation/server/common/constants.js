module.exports = {
    categories: [
        'Drinking',
        'SPAM',
        'Team Work',
        'Cinema',
        'Board Games'
    ],
    initiatives : [
        'Public',
        'Software Academy',
        'Algo Academy',
        'School Academy',
        'Kids Academy'
    ],
    seasons: [
        'None',
        'Started 2010',
        'Started 2011',
        'Started 2012',
        'Started 2013'
    ]
};