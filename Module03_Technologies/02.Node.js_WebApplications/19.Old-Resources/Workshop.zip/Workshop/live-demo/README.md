# Product Gallery

## Functionality

- Listing all products by pages
- List newest 10 products
- Add new product with name, description, price and image
	-	The image can be uploaded local file or by url in WWW

##	Demo

Live demo uploaded [here](https://product-gallery.herokuapp.com/)
