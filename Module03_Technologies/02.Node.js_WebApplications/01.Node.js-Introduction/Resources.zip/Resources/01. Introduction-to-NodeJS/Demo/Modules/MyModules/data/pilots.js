var ivoPilot = 'Ivaylo';
var nikiPilot = 'Niki';

module.exports.pilot = ivoPilot;