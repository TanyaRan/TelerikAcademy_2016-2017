var car = {
    make: 'Audi',
    model: 'R8',
    year: 2013
};

var engine = {
    hp: 500,
    fuel: 'Gas'
};

module.exports.audi = car;