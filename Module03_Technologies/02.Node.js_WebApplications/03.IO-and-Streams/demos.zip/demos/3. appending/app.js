/* globals require __dirname */


const logger = require("./utils/logger").getLogger(__dirname + "/logs/log.txt");
logger.log("It works!");