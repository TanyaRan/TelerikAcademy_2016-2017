var operations = require("./math-operations");

console.log(`Sum: ${operations.sum(1, 2)}`);
console.log(`Product: ${operations.multiply(1, 2)}`);