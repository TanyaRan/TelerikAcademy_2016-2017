/* globals module */

class Power {
    constructor(name) {
        this.name = name;
    }
}

module.exports = Power;